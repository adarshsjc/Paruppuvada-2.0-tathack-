AI INSTRUCTIONS
----------------
This is PART 6 out of 6 of a larger project. 
To ensure you understand the entire context:
1. Review the 'README.md', 'project.md', and 'design.md' files included in this folder. They define the overall goals and architecture.
2. Review the 'PROJECT_STRUCTURE.txt' file to understand how all the files connect across the entire project.
3. This part only contains a fraction of the actual code. Wait until all 6 parts are uploaded before providing a final analysis.
