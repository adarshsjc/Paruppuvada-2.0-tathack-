extension Foo {
    func two() {}
}
