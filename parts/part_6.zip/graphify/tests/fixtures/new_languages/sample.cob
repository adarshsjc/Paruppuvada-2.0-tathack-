       IDENTIFICATION DIVISION.
       PROGRAM-ID. SAMPLE.
       PROCEDURE DIVISION.
       MAIN-PARA.
           PERFORM HELPER-PARA.
           STOP RUN.
       HELPER-PARA.
           DISPLAY 'ok'.
