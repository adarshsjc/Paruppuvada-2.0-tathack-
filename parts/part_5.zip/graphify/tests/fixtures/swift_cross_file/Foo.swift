class Foo {
    func one() {}
}
